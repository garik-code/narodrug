<?php
interface Sabai_Addon_Form_IFields
{
    public function formGetFieldTypes();
    public function formGetField($type);
}