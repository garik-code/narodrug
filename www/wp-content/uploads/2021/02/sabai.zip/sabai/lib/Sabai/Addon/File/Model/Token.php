<?php
class Sabai_Addon_File_Model_Token extends Sabai_Addon_File_Model_Base_Token
{
}

class Sabai_Addon_File_Model_TokenRepository extends Sabai_Addon_File_Model_Base_TokenRepository
{
}