<?php
class Sabai_UnexpectedValueException extends UnexpectedValueException implements Sabai_IException {}