<?php
interface Sabai_IException {}