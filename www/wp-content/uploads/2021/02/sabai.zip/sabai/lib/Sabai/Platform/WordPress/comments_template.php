<?php
// This is a dummy file for WordPress to include when displaying comments on Sabai WordPress pages