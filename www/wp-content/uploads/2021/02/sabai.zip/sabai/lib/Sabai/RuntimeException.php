<?php
class Sabai_RuntimeException extends RuntimeException implements Sabai_IException {}