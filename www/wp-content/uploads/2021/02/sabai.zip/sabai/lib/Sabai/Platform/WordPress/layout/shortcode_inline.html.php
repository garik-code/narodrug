<?php
echo $CONTENT;