<?php
class Sabai_LogicException extends LogicException implements Sabai_IException {}