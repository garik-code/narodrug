<?php
class Sabai_InvalidArgumentException extends InvalidArgumentException implements Sabai_IException {}