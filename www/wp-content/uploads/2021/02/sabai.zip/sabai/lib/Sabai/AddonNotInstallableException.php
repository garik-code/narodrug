<?php
class Sabai_AddonNotInstallableException extends Sabai_RuntimeException {}