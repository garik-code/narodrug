<?php
class Sabai_BadMethodCallException extends BadMethodCallException implements Sabai_IException {}