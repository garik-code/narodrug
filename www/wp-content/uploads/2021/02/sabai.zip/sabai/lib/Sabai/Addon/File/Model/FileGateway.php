<?php
class Sabai_Addon_File_Model_FileGateway extends Sabai_Addon_File_Model_Base_FileGateway
{
}