<?php
class Sabai_AddonNotFoundException extends Sabai_RuntimeException {}