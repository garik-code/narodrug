<?php
interface Sabai_Addon_Entity_ITypes
{
    public function entityGetTypeNames();
    public function entityGetType($name);
}